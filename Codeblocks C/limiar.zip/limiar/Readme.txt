Codigo funcionando parcialmente.

Abre imagem
RGB2GRAY
THRESHOLD